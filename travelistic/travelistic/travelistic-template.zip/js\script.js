/**
 * TRAVELISTIC - Main JavaScript Engine
 * Author: Senior Frontend Developer & UI/UX Designer
 * Version: 1.0.0
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  /* --------------------------------------------------------------------------
     1. STICKY HEADER & SCROLL BEHAVIORS
     -------------------------------------------------------------------------- */
  const header = document.querySelector('.header');
  const backToTopBtn = document.querySelector('.back-to-top');
  const readingProgressBar = document.querySelector('.reading-progress-bar');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;

    // Sticky header background
    if (header) {
      if (scrollY > 60) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    // Back to top button visibility
    if (backToTopBtn) {
      if (scrollY > 400) {
        backToTopBtn.classList.add('active');
      } else {
        backToTopBtn.classList.remove('active');
      }
    }

    // Reading progress bar for single blog post
    if (readingProgressBar) {
      const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const progress = (scrollY / docHeight) * 100;
      readingProgressBar.style.width = `${progress}%`;
    }
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  /* --------------------------------------------------------------------------
     2. MOBILE NAVIGATION DRAWER
     -------------------------------------------------------------------------- */
  const hamburger = document.querySelector('.hamburger');
  const navMenu = document.querySelector('.nav-menu');
  const dropdownParents = document.querySelectorAll('.has-dropdown');

  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      const icon = hamburger.querySelector('i');
      if (icon) {
        if (navMenu.classList.contains('active')) {
          icon.classList.remove('fa-bars');
          icon.classList.add('fa-times');
        } else {
          icon.classList.remove('fa-times');
          icon.classList.add('fa-bars');
        }
      }
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!header.contains(e.target) && navMenu.classList.contains('active')) {
        navMenu.classList.remove('active');
        const icon = hamburger.querySelector('i');
        if (icon) {
          icon.classList.remove('fa-times');
          icon.classList.add('fa-bars');
        }
      }
    });

    // Mobile dropdown toggle
    dropdownParents.forEach(item => {
      const link = item.querySelector('.nav-link');
      if (link) {
        link.addEventListener('click', (e) => {
          if (window.innerWidth <= 768) {
            e.preventDefault();
            item.classList.toggle('open');
          }
        });
      }
    });
  }

  /* --------------------------------------------------------------------------
     3. SCROLL REVEAL ANIMATIONS (IntersectionObserver)
     -------------------------------------------------------------------------- */
  const revealElements = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window && revealElements.length > 0) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      threshold: 0.15,
      rootMargin: '0px 0px -40px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));
  } else {
    revealElements.forEach(el => el.classList.add('active'));
  }

  /* --------------------------------------------------------------------------
     4. ANIMATED STATISTIC COUNTERS
     -------------------------------------------------------------------------- */
  const counterElements = document.querySelectorAll('.stat-number');

  if ('IntersectionObserver' in window && counterElements.length > 0) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseInt(el.getAttribute('data-target') || el.innerText.replace(/[^0-9]/g, ''), 10);
          const suffix = el.getAttribute('data-suffix') || '+';
          const prefix = el.getAttribute('data-prefix') || '';
          const duration = 2000;
          const frameRate = 30;
          const totalFrames = Math.round(duration / (1000 / frameRate));
          let frame = 0;

          if (!isNaN(target)) {
            const counterInterval = setInterval(() => {
              frame++;
              const currentProgress = frame / totalFrames;
              const easeOutProgress = 1 - Math.pow(1 - currentProgress, 3);
              const currentCount = Math.round(easeOutProgress * target);

              el.innerText = `${prefix}${currentCount.toLocaleString()}${suffix}`;

              if (frame >= totalFrames) {
                clearInterval(counterInterval);
                el.innerText = `${prefix}${target.toLocaleString()}${suffix}`;
              }
            }, 1000 / frameRate);
          }

          observer.unobserve(el);
        }
      });
    }, { threshold: 0.5 });

    counterElements.forEach(el => counterObserver.observe(el));
  }

  /* --------------------------------------------------------------------------
     5. HERO SEARCH BAR TABS & FORM
     -------------------------------------------------------------------------- */
  const searchTabBtns = document.querySelectorAll('.search-tab-btn');
  const searchForm = document.querySelector('.search-form');

  if (searchTabBtns.length > 0) {
    searchTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        searchTabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const type = btn.getAttribute('data-type');
        if (type === 'flight') {
          showToast('Uçuş axtarış rejimi aktivləşdirildi ✈️', 'info');
        } else if (type === 'hotel') {
          showToast('Otel və rezort axtarış rejimi aktivləşdirildi 🏨', 'info');
        } else {
          showToast('Tur paketləri axtarış rejimi aktivləşdirildi 🌍', 'info');
        }
      });
    });
  }

  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const destination = searchForm.querySelector('input[name="destination"]')?.value || 'İstiqamət';
      const date = searchForm.querySelector('input[name="date"]')?.value || 'Təyin edilməmiş';
      const guests = searchForm.querySelector('select[name="guests"]')?.value || '1 nəfər';
      
      showToast(`"${destination}" üzrə axtarış icra edilir... (${guests})`, 'success');
      setTimeout(() => {
        window.location.href = 'services.html';
      }, 1000);
    });
  }

  /* --------------------------------------------------------------------------
     6. CATEGORY FILTERING (SERVICES & BLOG)
     -------------------------------------------------------------------------- */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const filterItems = document.querySelectorAll('.filterable-item');

  if (filterBtns.length > 0 && filterItems.length > 0) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filterValue = btn.getAttribute('data-filter');

        filterItems.forEach(item => {
          const category = item.getAttribute('data-category');
          if (filterValue === 'all' || category === filterValue || category?.includes(filterValue)) {
            item.style.display = 'flex';
            setTimeout(() => {
              item.style.opacity = '1';
              item.style.transform = 'scale(1)';
            }, 50);
          } else {
            item.style.opacity = '0';
            item.style.transform = 'scale(0.95)';
            setTimeout(() => {
              item.style.display = 'none';
            }, 300);
          }
        });
      });
    });
  }

  /* --------------------------------------------------------------------------
     7. TOUR GALLERY SWITCHER (SERVICE-SINGLE)
     -------------------------------------------------------------------------- */
  const mainGalleryImg = document.querySelector('.tour-gallery-main img');
  const thumbGalleryImgs = document.querySelectorAll('.tour-gallery-thumb');

  if (mainGalleryImg && thumbGalleryImgs.length > 0) {
    thumbGalleryImgs.forEach(thumb => {
      thumb.addEventListener('click', () => {
        thumbGalleryImgs.forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        const newSrc = thumb.querySelector('img').getAttribute('src');
        
        mainGalleryImg.style.opacity = '0.3';
        setTimeout(() => {
          mainGalleryImg.setAttribute('src', newSrc);
          mainGalleryImg.style.opacity = '1';
        }, 200);
      });
    });
  }

  /* --------------------------------------------------------------------------
     8. DAY-BY-DAY ITINERARY ACCORDION (SERVICE-SINGLE)
     -------------------------------------------------------------------------- */
  const itineraryHeaders = document.querySelectorAll('.itinerary-header');

  if (itineraryHeaders.length > 0) {
    itineraryHeaders.forEach(header => {
      header.addEventListener('click', () => {
        const parentItem = header.parentElement;
        const isActive = parentItem.classList.contains('active');

        // Toggle clicked item
        if (isActive) {
          parentItem.classList.remove('active');
        } else {
          parentItem.classList.add('active');
        }
      });
    });
  }

  /* --------------------------------------------------------------------------
     9. TOUR LIVE BOOKING CALCULATOR
     -------------------------------------------------------------------------- */
  const guestSelect = document.querySelector('#booking-guests');
  const packageTypeSelect = document.querySelector('#booking-package-type');
  const basePricePerPerson = 1290; // Default base price in AZN

  function updateBookingPrice() {
    const guests = parseInt(guestSelect?.value || '1', 10);
    const multiplier = parseFloat(packageTypeSelect?.value || '1.0');
    const pricePerPerson = Math.round(basePricePerPerson * multiplier);
    const subtotal = pricePerPerson * guests;
    const taxes = Math.round(subtotal * 0.05); // 5% service fee/tax
    const total = subtotal + taxes;

    const baseEl = document.querySelector('#calc-base-price');
    const taxEl = document.querySelector('#calc-tax-price');
    const totalEl = document.querySelector('#calc-total-price');

    if (baseEl) baseEl.innerText = `${subtotal.toLocaleString()} ₼`;
    if (taxEl) taxEl.innerText = `${taxes.toLocaleString()} ₼`;
    if (totalEl) totalEl.innerText = `${total.toLocaleString()} ₼`;
  }

  if (guestSelect) guestSelect.addEventListener('change', updateBookingPrice);
  if (packageTypeSelect) packageTypeSelect.addEventListener('change', updateBookingPrice);

  /* --------------------------------------------------------------------------
     10. BOOKING MODAL & INTERACTION
     -------------------------------------------------------------------------- */
  const modalOverlay = document.querySelector('.modal-overlay');
  const modalCloseBtn = document.querySelector('.modal-close-btn');
  const openModalBtns = document.querySelectorAll('.open-booking-modal');
  const modalTourName = document.querySelector('#modal-tour-name');

  if (modalOverlay) {
    openModalBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const tourTitle = btn.getAttribute('data-tour') || 'Seçilmiş Tur Paketi';
        if (modalTourName) modalTourName.innerText = tourTitle;
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    });

    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
      });
    }

    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
      }
    });

    const modalForm = document.querySelector('#modal-booking-form');
    if (modalForm) {
      modalForm.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Təşəkkür edirik! Rezervasiya sorğunuz qəbul edildi. Menecerimiz 15 dəqiqə ərzində sizinlə əlaqə saxlayacaq.', 'success');
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
        modalForm.reset();
      });
    }
  }

  /* --------------------------------------------------------------------------
     11. CONTACT & NEWSLETTER FORMS
     -------------------------------------------------------------------------- */
  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = contactForm.querySelector('input[name="name"]')?.value || 'Dəyərli Müştəri';
      showToast(`Təşəkkür edirik, ${name}! Mesajınız uğurla göndərildi. Tezliklə cavablandırılacaq.`, 'success');
      contactForm.reset();
    });
  }

  const newsletterForms = document.querySelectorAll('.newsletter-form');
  newsletterForms.forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = form.querySelector('input[type="email"]');
      if (emailInput && emailInput.value.trim() !== '') {
        showToast('Təbrik edirik! VIP səyahət təkliflərinə uğurla abunə oldunuz 🎁', 'success');
        form.reset();
      } else {
        showToast('Zəhmət olmasa düzgün e-poçt ünvanı daxil edin.', 'error');
      }
    });
  });

  const commentForm = document.querySelector('#comment-form');
  if (commentForm) {
    commentForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Şərhiniz üçün təşəkkürlər! Yoxlanışdan sonra dərc ediləcək.', 'success');
      commentForm.reset();
    });
  }

  /* --------------------------------------------------------------------------
     12. COPY SHARE LINK
     -------------------------------------------------------------------------- */
  const copyLinkBtn = document.querySelector('#copy-link-btn');
  if (copyLinkBtn) {
    copyLinkBtn.addEventListener('click', (e) => {
      e.preventDefault();
      navigator.clipboard.writeText(window.location.href).then(() => {
        showToast('Məqalənin linki kopyalandı! 📋', 'success');
      }).catch(() => {
        showToast('Link kopyalana bilmədi.', 'error');
      });
    });
  }

  /* --------------------------------------------------------------------------
     13. TOAST NOTIFICATION UTILITY
     -------------------------------------------------------------------------- */
  window.showToast = function(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';

    toast.innerHTML = `<i class="fas ${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(50px)';
      toast.style.transition = 'all 0.3s ease-out';
      setTimeout(() => {
        if (toast.parentElement) {
          toast.remove();
        }
      }, 300);
    }, 3800);
  };
});
